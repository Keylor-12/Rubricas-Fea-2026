const express = require("express");
const mariadb = require("mariadb");
const cors = require("cors");
 
const app = express();
 
app.use(cors());
app.use(express.json());
const path = require('path');

// Servir archivos estáticos desde la carpeta del proyecto
app.use(express.static(path.join(__dirname, '..')));

const pool = mariadb.createPool({
    host: "localhost",
    user: "root",
    password: "1234",
    database: "fea2026",
    connectionLimit: 5
});
 
app.post("/guardar-coreografia", async (req, res) => {
 
    try {
 
        const datos = req.body;
 
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO calificaciones_coreografia
            (
                fecha,
                juez,
                participante,
                foto,
                centro,
                niveles,
                formativos,
                manual,
                tecnico,
                total,
                recomendada
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                datos.fecha,
                datos.juez,
                datos.participante,
                datos.foto,
                datos.centro,
                datos.niveles,
                datos.formativos,
                datos.manual,
                datos.tecnico,
                datos.total,
                datos.recomendada
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Coreografía guardada"
        });
        
 
    } catch (error) {
 
        console.log(error);
 
        res.status(500).json({
            error: "Error servidor"
        });
    }
});
app.post("/guardar-poesia_coral", async (req, res) => {
 
    try {
 
        const datos = req.body;
 
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO poesia_coral 
            (
                fecha,
                juez,
                participante,
                foto,
                centro,
                niveles,
                formativos,
                manual,
                tecnico,
                total,
                recomendada
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                datos.fecha,
                datos.juez,
                datos.participante,
                datos.foto,
                datos.centro,
                datos.niveles,
                datos.formativos,
                datos.manual,
                datos.tecnico,
                datos.total,
                datos.recomendada
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Coreografía guardada"
        });
        
 
    } catch (error) {
 
        console.log(error);
 
        res.status(500).json({
            error: "Error servidor"
        });
    }
});
 
app.post("/guardar-fotografia", async (req, res) => {
 
    try {
 
        const datos = req.body;
 
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO fotografia
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Fotografía guardada"
        });
 
    } catch (error) {
 
        console.log(error);
 
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-folclore", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO folclore
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Folclore guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-cuenta-cuentos", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO cuenta_cuentos
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Cuenta cuentos guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-cuento", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO cuento
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Cuento guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-cuento-ilustrado", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO cuento_ilustrado
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Cuento ilustrado guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-dibujo", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO dibujo
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Dibujo guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-garaje", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO garaje
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Garaje guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-original", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO original
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Original guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-poesia", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO poesia
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Poesía guardada"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-poesia-coral", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO poesia_coral
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Poesía coral guardada"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-tipico", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO tipico
            (
                participante,
                juez,
                puntuacion,
                url_imagen,
                comentarios
            )
            VALUES (?, ?, ?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion,
                datos.url_imagen || null,      // Si no se envía, guarda NULL
                datos.comentarios || null       // Si no se envía, guarda NULL
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "tipico guardada exitosamente",
            datos_recibidos: datos
        });
 
    } catch (error) {
        console.log(error);
        
        // Manejo de errores específicos
        if (error.code === 'ER_DUP_ENTRY') {
            res.status(400).json({
                error: "Ya existe un registro con esta combinación"
            });
        } else {
            res.status(500).json({
                error: "Error interno del servidor al guardar la fotografía"
            });
        }
    }
});
app.post("/guardar-popular", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO popular
            (
                participante,
                juez,
                puntuacion,
                url_imagen,
                comentarios
            )
            VALUES (?, ?, ?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion,
                datos.url_imagen || null,      // Si no se envía, guarda NULL
                datos.comentarios || null       // Si no se envía, guarda NULL
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "popular guardada exitosamente",
            datos_recibidos: datos
        });
 
    } catch (error) {
        console.log(error);
        
        // Manejo de errores específicos
        if (error.code === 'ER_DUP_ENTRY') {
            res.status(400).json({
                error: "Ya existe un registro con esta combinación"
            });
        } else {
            res.status(500).json({
                error: "Error interno del servidor al guardar la fotografía"
            });
        }
    }
});
app.post("/guardar-produccion-audiovisual", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO produccion_audiovisual
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Producción audiovisual guardada"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.post("/guardar-teatro", async (req, res) => {
 
    try {
        const datos = req.body;
        const conn = await pool.getConnection();
 
        await conn.query(
            `
            INSERT INTO teatro
            (
                participante,
                juez,
                puntuacion
            )
            VALUES (?, ?, ?)
            `,
            [
                datos.participante,
                datos.juez,
                datos.puntuacion
            ]
        );
 
        conn.release();
 
        res.json({
            mensaje: "Teatro guardado"
        });
 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            error: "Error"
        });
    }
});
app.get("/admin/resultados", async (req, res) => {
    const adminKey = req.headers['x-admin-key'];
    if (adminKey !== 'fea2026admin') {
        return res.status(401).json({ error: "No autorizado" });
    }
 
    try {
        const conn = await pool.getConnection();
 
        // Tablas simples: participante, juez, puntuacion
        const tablasSimples = [
            { tabla: 'fotografia',            categoria: 'Fotografía' },
            { tabla: 'folclore',              categoria: 'Folclore' },
            { tabla: 'cuenta_cuentos',        categoria: 'Cuenta Cuentos' },
            { tabla: 'cuento',                categoria: 'Cuento' },
            { tabla: 'cuento_ilustrado',      categoria: 'Cuento Ilustrado' },
            { tabla: 'dibujo',                categoria: 'Dibujo' },
            { tabla: 'garaje',                categoria: 'Música de Garaje' },
            { tabla: 'original',              categoria: 'Música Original' },
            { tabla: 'poesia',                categoria: 'Poesía' },
            { tabla: 'poesia_coral',          categoria: 'Poesía Coral' },
            { tabla: 'tipico',                categoria: 'Música Típica' },
            { tabla: 'popular',               categoria: 'Música Popular' },
            { tabla: 'produccion_audiovisual',categoria: 'Producción Audiovisual' },
            { tabla: 'teatro',                categoria: 'Teatro' },
        ];
 
        let resultados = [];
 
        for (const t of tablasSimples) {
            try {
                const filas = await conn.query(
                    `SELECT participante, SUM(puntuacion) AS total_puntos, COUNT(juez) AS cantidad_jueces
                     FROM \`${t.tabla}\`
                     GROUP BY participante
                     ORDER BY total_puntos DESC`
                );
                filas.forEach(f => {
                    resultados.push({
                        categoria: t.categoria,
                        participante: f.participante,
                        total_puntos: Number(f.total_puntos),
                        cantidad_jueces: Number(f.cantidad_jueces)
                    });
                });
            } catch(e) {
                // Si la tabla no existe aún, la ignoramos
            }
        }
 
        // Tabla especial: coreografía (usa columna 'total' por fila)
        try {
            const coreo = await conn.query(
                `SELECT participante, SUM(total) AS total_puntos, COUNT(juez) AS cantidad_jueces
                 FROM calificaciones_coreografia
                 GROUP BY participante
                 ORDER BY total_puntos DESC`
            );
            coreo.forEach(f => {
                resultados.push({
                    categoria: 'Coreografía Popular',
                    participante: f.participante,
                    total_puntos: Number(f.total_puntos),
                    cantidad_jueces: Number(f.cantidad_jueces)
                });
            });
        } catch(e) {}
 
        conn.release();
        res.json(resultados);
 
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Error servidor" });
    }
});
 
app.listen(3000, () => {
    console.log("Servidor corriendo en puerto 3000");
});
